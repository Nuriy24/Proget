import './bootstrap';
function toggleSidebar() {
  const sidebar = document.getElementById('sidebar');
  sidebar.style.left = sidebar.style.left === '0px' ? '-250px' : '0px';
}

function closeSidebar() {
  document.getElementById('sidebar').style.left = '-250px';
}

function showDescription(text) {
  document.getElementById('description').innerText = text;
}