<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Школа танцев Нур</title>
    <link rel="stylesheet" href="css/main.css">
</head>
<body>
<header>
    <img src="https://yt3.googleusercontent.com/ytc/AIdro_nySrc1NjA8oDAQ6zfMnniTUcPl02wIecPIMFAXr_8BTw=s900-c-k-c0x00ffffff-no-rj" alt="Логотип" class="logo">
    <h1>Школа танцев "Лезгинка Нур"</h1>
</header>
<div class="burger" onclick="toggleSidebar()">
    <div></div>
    <div></div>
    <div></div>
</div>
<nav id="nav">
    <a href="#about">О школе</a>
    <a href="#gallery">Галерея</a>
    <a href="#directions">Направления танцев</a>
    <a href="#prices">Цены</a>
    <a href="#shop">Магазин</a>
    <a href="#contact">Контакты</a>
</nav>
<div class="redesigned-group-cover__img" style="background-image:url(https://sun9-7.userapi.com/impf/7D9YXOyN8qDsJ1IsFlAK9eET0c5TzXSbX-2jCA/jjr9-_SF0W8.jpg?size=1920x768&quality=95&crop=0,0,1920,767&sign=d41864c54310df39ad010a284ac729d2&type=cover_group)"></div>
<div class="sidebar" id="sidebar">
    <a href="#about" onclick="closeSidebar()">О школе</a>
    <a href="#gallery" onclick="closeSidebar()">Галерея</a>
    <a href="#directions" onclick="closeSidebar()">Направления танцев</a>
    <a href="#prices" onclick="closeSidebar()">Цены</a>
    <a href="#shop" onclick="closeSidebar()">Магазин</a>
    <a href="#contact" onclick="closeSidebar()">Контакты</a>
</div>
<div class="content">
    <h2 id="about">О школе</h2>
    <p>Добро пожаловать в Школу танцев "Лезгинка Нур". У нас Вы сможете научиться танцевать и раскрыть свой талант!</p>
    <img src="https://avatars.mds.yandex.net/get-altay/13197739/2a000001918e57b01e24a0a8d9f0d6af18d7/XXXL" alt="Фото" width="1000">
    <h2 id="gallery">Галерея</h2>
    <div class="gallery">
        <div class="photo" onclick="showDescription('Описание танца 1')">
            <img src="https://avatars.mds.yandex.net/get-altay/5254653/2a0000017b35400e7d22a5c19f3fb1971293/XXL_height" alt="Танец 1">
        </div>
        <div class="photo" onclick="showDescription('Описание танца 2')">
            <img src="https://avatars.mds.yandex.net/get-altay/11748256/2a000001918e57adf0cbff40953e8a63415a/XXXL" alt="Танец 2">
        </div>
        <div class="photo" onclick="showDescription('Описание танца 3')">
            <img src="https://avatars.mds.yandex.net/get-altay/13987456/2a000001918e57aa785cb72f18691795df21/XXXL" alt="Танец 3">
        </div>
    </div>
    <div id="description" class="description"></div>
</div>
<footer id="footerwrap">
    <div class="contacts">
        <p>Контакты:</p>
        <p>Телефон: 8 (980) 247-43-97</p>
        <p>Email: <a href="mailto:Lezginka-nur@yandex.ru">Lezginka-nur@yandex.ru</a></p>
    </div>
</footer>
<script src="js/test.js"></script>
</body>
</html>