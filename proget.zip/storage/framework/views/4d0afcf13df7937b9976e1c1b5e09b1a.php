<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Школа танцев "Лезгинка Нур"</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
        }
        header {
            background-color: #ff5733;
            color: white;
            padding: 10px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: fixed;
            width: 100%;
            top: 0;
            z-index: 1000;
        }
        .logo {
            height: 50px;
        }
        nav {
            margin-top: 60px;
            background: #fff;
            padding: 10px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
        }
        nav a {
            margin: 0 15px;
            text-decoration: none;
            color: #333;
        }
        .burger {
            display: flex;
            flex-direction: column;
            cursor: pointer;
        }
        .burger div {
            height: 3px;
            width: 30px;
            background-color: white;
            margin: 4px;
            transition: 0.3s;
        }
        .sidebar {
            display: none;
            position: fixed;
            top: 60px;
            right: 0;
            background: #fff;
            box-shadow: -2px 0 5px rgba(0, 0, 0, 0.2);
            padding: 20px;
            width: 200px;
        }
        .sidebar a {
            display: block;
            margin: 10px 0;
        }
        .content {
            margin-top: 80px;
            padding: 20px;
        }
        .gallery {
            display: flex;
            justify-content: space-around;
            flex-wrap: wrap;
        }
        .photo {
            margin: 10px;
            cursor: pointer;
        }
        .description {
            margin-top: 20px;
            font-style: italic;
        }
        footer {
            background-color: #ff5733;
            color: white;
            text-align: center;
            padding: 20px;
            position: relative;
            bottom: 0;
            left: 0;
            right: 0;
        }
        @media (max-width: 768px) {
            .burger {
                display: block;
            }

            nav {
                display: none;
                flex-direction: column;
                background-color: white;
                position: absolute;
                width: 100%;
                top: 70px;
                left
            
    </style>
</head>
<body>
<header>
    <img src="https://yt3.googleusercontent.com/ytc/AIdro_nySrc1NjA8oDAQ6zfMnniTUcPl02wIecPIMFAXr_8BTw=s900-c-k-c0x00ffffff-no-rj" alt="Логотип" class="logo">
    <h1>Школа танцев "Лезгинка Нур"</h1>
    <div class="burger" onclick="toggleSidebar()">
        <div></div>
        <div></div>
        <div></div>
    </div>
</header>

<nav id="nav">
    <a href="#about">О школе</a>
    <a href="#gallery">Галерея</a>
    <a href="#directions">Направления танцев</a>
    <a href="#prices">Цены</a>
    <a href="#shop">Магазин</a>
    <a href="#contact">Контакты</a>
</nav>

<div class="sidebar" id="sidebar">
    <a href="#about" onclick="closeSidebar()">О школе</a>
    <a href="#gallery" onclick="closeSidebar()">Галерея</a>
    <a href="#directions" onclick="closeSidebar()">Направления танцев</a>
    <a href="#prices" onclick="closeSidebar()">Цены</a>
    <a href="#shop" onclick="closeSidebar()">Магазин</a>
    <a href="#contact" onclick="closeSidebar()">Контакты</a>
</div>

<div class="content">
    <h2 id="about">О школе</h2>
    <p>Добро пожаловать в Школу танцев "Лезгинка Нур". У нас Вы сможете научиться танцевать и раскрыть свой талант!</p>
    <img src="https://avatars.mds.yandex.net/get-altay/13197739/2a000001918e57b01e24a0a8d9f0d6af18d7/XXXL" alt="Фото" width="1000">

    <h2 id="gallery">Галерея</h2>
    <div class="gallery">
        <div class="photo" onclick="showDescription('Описание танца 1')">
            <img src="https://avatars.mds.yandex.net/get-altay/5254653/2a0000017b35400e7d22a5c19f3fb1971293/XXL_height" alt="Танец 1" width="300">
        </div>
        <div class="photo" onclick="showDescription('Описание танца 2')">
            <img src="https://avatars.mds.yandex.net/get-altay/11748256/2a000001918e57adf0cbff40953e8a63415a/XXXL" alt="Танец 2" width="300">
        </div>
        <div class="photo" onclick="showDescription('Описание танца 3')">
            <img src="https://avatars.mds.yandex.net/get-altay/13987456/2a000001918e57aa785cb72f18691795df21/XXXL" alt="Танец 3" width="300">
        </div>
    </div>
    <div id="description" class="description"></div>
</div>

<footer>
    <div class="contacts">
        <p>Контакты:</p>
        <p>Телефон: <strong>8 (980) 247-43-97</strong></p>
        <p>Email: <a href="mailto:Lezginka-nur@yandex.ru">Lezginka-nur@yandex.ru</a></p>
    </div>
</footer>

<script>
    function toggleSidebar() {
        const sidebar = document.getElementById("sidebar");
        sidebar.style.display = sidebar.style.display === "block" ? "none" : "block";
    }

    function closeSidebar() {
        document.getElementById("sidebar").style.display = "none";
    }

    function showDescription(text) {
        document.getElementById("description").innerText = text;
    }
</script>
</body>
</html>
<?php /**PATH C:\progect\proget\resources\views/about.blade.php ENDPATH**/ ?>